package br.edu.satc.todolistcompose

data class TaskData (
    val title: String,
    val description: String,
    val complete: Boolean
)